    <footer class="footer-dark">
        <div class="container">
            <div class="row">                
                <div class="col-md-7 col-7 left">                  
                    <h3 class="title">QUICK LINKS</h3>
                    <div class="inner">
                        <a href="website.php"><p>Best Web Developers in Chennai<br></p></a>
                        <a href="android.php"><p>Best Android Developers in Chennai<br></p></a>
                        <a href="ios.php"><p>Best iOS Developers in Chennai<br></p></a>
                        <a href="seo.php"><p>Best Digital Marketing Agency in Chennai</p></a>
                        <a href="seo.php"><p>Best SEO Company in Chennai<br></p></a>
                    </div>                          
                </div>
                <!-- <div class="col-md-5 col-5 right">
                    <h3 class="title">Colon Developers</h3>  
                    <div class="inner" style="text-align:left">                                                  
                        <p class="icons" style="padding:0;">
                            <a href="#" class="inner-main-icon">
                            <a href="#" class="inner-main-icon"></i></a>                            
                            <a href="#" class="inner-main-icon"></a>             
                        </p>
                        <p style="width:auto;">Made with <i class="fa fa-heart color-white"></i> in India by Tech4LYF.</p>
                    </div>
                </div>               -->
                <div class="col-md-5 col-5">
                    <div class="right">
                        <h3 class="title">Colon Developers</h3> 
                        <div class="footer_icon">
                            <div class="inner_main_icon" >
                                <i class="fa-brands fa-facebook-f"></i>
                            </div>
                            <div class="inner_main_icon">
                                <i class="fa-brands fa-instagram"></i>
                            </div>
                            <div class="inner_main_icon">
                                <i class="fa-brands fa-twitter"></i>
                            </div>
                        </div>
                        <p class="slogan" style="width:auto;">Made with <i class="fa fa-heart color-white"></i> in India by Tech4LYF.</p>
                    </div>
                </div>
            </div>                                 
        </div>
    </footer>